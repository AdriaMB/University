// UTILITZACIÓ: Copieu al Code Pad de BlueJ cada línia, una a una
// L'eixida es deuria mostrar a la Ventana de Terminal. Si no hi apareix, reinicieu BlueJ i repetiu

String [] palabra = {"saco", "asco", "noreste", "enteros", "cronista", "cortinas"};

int [] base = {1, 4, 31};

for (int i = 0; i < palabra.length; i++) { System.out.println(palabra[i]); for (int j = 0; j < base.length; j++) { Termino t = new Termino(palabra[i], base[j]); System.out.printf("\tbase %2d: "+t.hashCode()+"\n", base[j]);} System.out.println("==========================================");}

// NO CAL COPIAR AÇÒ, simplement es mostra el codi estructurat
//String [] palabra = {"saco", "asco", "noreste", "enteros", "cronista", "cortinas"};
//int [] base = {1, 4, 31};
//for (int i = 0; i < palabra.length; i++) { 
// 	System.out.println(palabra[i]); 
//	for (int j = 0; j < base.length; j++) { 
//		Termino t = new Termino(palabra[i], base[j]); 
//		System.out.printf("\tbase %2d: "+t.hashCode()+"\n", base[j]);
//	}
//	System.out.println("==========================================");
//}

