import librerias.estructurasDeDatos.modelos.ListaConPI;
ListaConPI<Termino> hapax10 = buscador1.hapax();
hapax10.talla()
hapax10.inicio();
// primer element: traté
hapax10.recuperar().toString()
hapax10.siguiente();
hapax10.siguiente();
// tercer element: monopolizar
hapax10.recuperar().toString()
String hapaxString = hapax10.toString();
int i  = hapaxString.lastIndexOf(",");
String ultimTerme = hapaxString.substring(i+1);
// últim element: estantes
ultimTerme