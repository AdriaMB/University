// USAGE: Copy line by line into BlueJ's Code Pad 
// The output should be shown at the Terminal Window.

String [] words = {"saco", "asco", "noreste", "enteros", "cronista", "cortinas"};

int [] base = {1, 4, 31};

for (int i = 0; i < words.length; i++) { System.out.println(words[i]); for (int j = 0; j < base.length; j++) { Term t = new Term(words[i], base[j]); System.out.printf("\tbase %2d: "+t.hashCode()+"\n", base[j]);} System.out.println("==========================================");}

// NO NEED TO COPY THIS, it is just the structured code
//String [] words = {"saco", "asco", "noreste", "enteros", "cronista", "cortinas"};
//int [] base = {1, 4, 31};
//for (int i = 0; i < words.length; i++) { 
// 	System.out.println(words[i]); 
//	for (int j = 0; j < base.length; j++) { 
//		Termino t = new Termino(words[i], base[j]); 
//		System.out.printf("\tbase %2d: "+t.hashCode()+"\n", base[j]);
//	}
//	System.out.println("==========================================");
//}

