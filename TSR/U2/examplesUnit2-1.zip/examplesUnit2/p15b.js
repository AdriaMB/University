function multiplyBy(x) {
	return (y)=>x*y
}
let triplicate = multiplyBy(3)
console.log(triplicate(21))
