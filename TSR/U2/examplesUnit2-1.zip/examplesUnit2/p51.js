const cir = require('./Circle.js')

console.log("Área círculo de radio 5: " 
     + cir.area(5));
