#include <stdio.h>

#define PI 3.1416
int main() {   
   float area, radius;
   radius = 10;   
   area = PI * (radius * radius);   
   printf("Area of circle with radius %f is %f \n", radius, area); 
}

