 void init_presentacion (void);
 void vuelca_memoria ( 
	programa_t *prog
	 );
 void init_instruc ( 
	word PC,
	ciclo_t orden
	 );
 void actualiza_crono (void);
 void imprime_css (void);
 void imprime_inicio_css (void);
 void imprime_final_css (void);
