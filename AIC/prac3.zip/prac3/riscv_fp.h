/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * File:   riscV_fp.h
 * Author: plopez
 *
 * Created on 7 de noviembre de 2017, 9:51
 */

#ifndef RISCV_FP_H
#define RISCV_FP_H

#ifdef __cplusplus
extern "C" {
#endif

#ifndef CPROTO
#include "riscv_fp_api.h"
#endif

#ifdef __cplusplus
}
#endif

#endif /* RISCV_FP_H */

