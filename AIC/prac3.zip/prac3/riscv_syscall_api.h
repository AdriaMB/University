 boolean process_syscall ( 
	dword PC
	 );
