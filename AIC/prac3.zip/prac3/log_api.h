 void write_log_2 ( 
	char *senyal,
	dword pc_read,
	dword pc_write,
	char *fase_read,
	char *fase_write
	 );
 void write_log_1x ( 
	char *senyal,
	dword pc,
	uint8_t reg
	 );
 void write_log_1f ( 
	char *senyal,
	dword pc,
	uint8_t reg
	 );
 void write_log ( 
	char *senyal,
	dword pc
	 );
