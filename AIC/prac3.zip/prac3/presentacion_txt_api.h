 void imprime_mapa_memoria (void);
 void imprime_inicio_txt (void);
 void imprime_final_txt (void);
 void imprime_etapas_txt (void);
 void imprime_reg_txt (void);
 void imprime_memdatos_txt (void);
