 void fase_busqueda (void);
 void fase_decodificacion (void);
 void fase_ejecucion (void);
 void fase_memoria (void);
 int fase_escritura (void);
 void fase_escritura_FP (void);
 void impulso_reloj (void);
