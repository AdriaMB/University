
/* Funciones exportables */

#ifndef CPROTO
#include "riscv_syscall_api.h"
#endif
