/* f_confirmacion_alum.c */
 void fase_COM_alum (void);
