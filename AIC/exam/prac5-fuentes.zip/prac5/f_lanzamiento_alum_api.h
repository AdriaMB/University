/* f_lanzamiento_alum.c */
 boolean fase_ISS_alum (void);
