 void g_color_enable (void);
 void g_color_disable (void);
 int g_color_is_enabled (void);
 void g_color_set ( 
	g_string_t *str,
	char *color
	 );
 void g_color_rgb ( 
	g_string_t *str,
	char *color,
	int r,
	int g,
	int b
	 );
 void g_color_reset ( 
	g_string_t *str
	 );
 void g_color_default ( 
	g_string_t *str
	 );
