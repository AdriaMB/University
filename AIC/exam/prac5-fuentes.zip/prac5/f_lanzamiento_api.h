 boolean fase_ISS (void);
