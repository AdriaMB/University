 void vuelca_jerarquia_en_memoria_datos (void);
 int main ( 
	int argc,
	char *argv[]
	 );
