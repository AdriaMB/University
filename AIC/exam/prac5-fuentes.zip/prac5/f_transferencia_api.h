 void fase_WB (void);
