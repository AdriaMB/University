 void decode_error ( 
	dword PC,
	format_decode_type decode,
	char *fail
	 );
 codop_t obtener_decodificacion ( 
	dword PC,
	format_decode_type decode,
	char **p_nemo,
	int *p_subfmt,
	formato_t *p_format
	 );
