 void fase_IF_1 ( 
	operacion_busqueda_t *busqueda,
	dword PC,
	ciclo_t orden
	 );
 void fase_IF_2 (void);
